package com.jada.blackledger;

import io.papermc.paper.event.player.AsyncChatEvent;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.serializer.plain.PlainTextComponentSerializer;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.entity.Player;
import org.bukkit.entity.TextDisplay;
import org.bukkit.entity.Display;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.player.PlayerEditBookEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.BookMeta;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.scoreboard.Scoreboard;
import org.bukkit.scoreboard.Team;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

public final class BlackLedger extends JavaPlugin implements Listener {
    private final Map<UUID, String> aliases = new HashMap<>();
    private final Set<UUID> deadPlayers = new HashSet<>();
    private NamespacedKey ledgerKey;
    private boolean gameRunning = false;
    private Team hiddenTeam;
    private final Map<UUID, TextDisplay> aliasDisplays = new HashMap<>();

    @Override
    public void onEnable() {
        saveDefaultConfig();
        ledgerKey = new NamespacedKey(this, "death_note");
        getServer().getPluginManager().registerEvents(this, this);
        setupTeam();
        getCommand("deathnote").setExecutor(new LedgerCommand(this));
        getLogger().info("Black Ledger enabled.");
    }

    @Override
    public void onDisable() {
        restoreRealNames();
        removeAliasDisplays();
    }

    private void setupTeam() {
        Scoreboard board = Bukkit.getScoreboardManager().getMainScoreboard();
        hiddenTeam = board.getTeam("BlackLedgerHidden");
        if (hiddenTeam == null) hiddenTeam = board.registerNewTeam("BlackLedgerHidden");
        hiddenTeam.setOption(Team.Option.NAME_TAG_VISIBILITY, Team.OptionStatus.NEVER);
    }

    public void startGame() {
        aliases.clear();
        deadPlayers.clear();
        gameRunning = true;
        int i = 1;
        for (Player p : Bukkit.getOnlinePlayers()) {
            aliases.put(p.getUniqueId(), createAlias(i++));
            applyMysteryIdentity(p);
            showAliasAboveHead(p);
            giveDeathNote(p);
        }
        Bukkit.broadcast(Component.text("The Black Ledger game has begun.", NamedTextColor.DARK_PURPLE));
        for (Player p : Bukkit.getOnlinePlayers()) {
            p.sendMessage(Component.text("Your secret identity is " + aliases.get(p.getUniqueId()) + ".", NamedTextColor.LIGHT_PURPLE));
            p.sendMessage(Component.text("Find out another player's real Minecraft username, write it in your Death Note, and sign the book.", NamedTextColor.GRAY));
        }
    }

    public void stopGame() {
        gameRunning = false;
        restoreRealNames();
        removeAliasDisplays();
        aliases.clear();
        deadPlayers.clear();
        Bukkit.broadcast(Component.text("The Black Ledger game has ended.", NamedTextColor.GRAY));
    }

    private String createAlias(int number) {
        List<String> prefixes = getConfig().getStringList("alias-prefixes");
        if (prefixes.isEmpty()) prefixes = List.of("Raven", "Wisp", "Cipher", "Veil");
        return prefixes.get((number - 1) % prefixes.size()) + "-" + String.format("%02d", number);
    }

    private void applyMysteryIdentity(Player p) {
        String alias = aliases.getOrDefault(p.getUniqueId(), "Unknown");
        p.setPlayerListName(alias);
        p.displayName(Component.text(alias));
        if (hiddenTeam != null && !hiddenTeam.hasPlayer(p)) hiddenTeam.addPlayer(p);
    }

    /**
     * Shows the mystery alias above the player's head while the real Minecraft
     * name tag is hidden. A TextDisplay is used because the player's vanilla
     * name tag must remain invisible to other players.
     */
    private void showAliasAboveHead(Player p) {
        removeAliasDisplay(p);
        String alias = aliases.getOrDefault(p.getUniqueId(), "Unknown");
        TextDisplay display = p.getWorld().spawn(p.getLocation().add(0, 0.35, 0), TextDisplay.class, entity -> {
            entity.text(Component.text(alias, NamedTextColor.LIGHT_PURPLE));
            entity.setBillboard(Display.Billboard.CENTER);
            entity.setSeeThrough(false);
            entity.setShadowed(true);
            entity.setDefaultBackground(false);
            entity.setPersistent(false);
        });
        p.addPassenger(display);
        aliasDisplays.put(p.getUniqueId(), display);
    }

    private void removeAliasDisplay(Player p) {
        TextDisplay display = aliasDisplays.remove(p.getUniqueId());
        if (display != null && !display.isDead()) display.remove();
    }

    private void removeAliasDisplays() {
        for (TextDisplay display : aliasDisplays.values()) {
            if (display != null && !display.isDead()) display.remove();
        }
        aliasDisplays.clear();
    }

    private void restoreRealNames() {
        for (Player p : Bukkit.getOnlinePlayers()) {
            p.setPlayerListName(p.getName());
            p.displayName(Component.text(p.getName()));
            if (hiddenTeam != null) hiddenTeam.removePlayer(p);
        }
    }

    private void giveDeathNote(Player p) {
        ItemStack note = new ItemStack(Material.WRITABLE_BOOK);
        BookMeta meta = (BookMeta) note.getItemMeta();
        meta.displayName(Component.text("Death Note", NamedTextColor.DARK_PURPLE));
        meta.lore(List.of(Component.text("Write a player's real Minecraft username.", NamedTextColor.GRAY),
                Component.text("Sign the book to invoke the Ledger.", NamedTextColor.GRAY)));
        meta.getPersistentDataContainer().set(ledgerKey, PersistentDataType.BYTE, (byte) 1);
        note.setItemMeta(meta);
        p.getInventory().addItem(note);
    }

    public boolean isDeathNote(ItemStack item) {
        if (item == null || item.getType() != Material.WRITABLE_BOOK) return false;
        if (!(item.getItemMeta() instanceof BookMeta meta)) return false;
        return meta.getPersistentDataContainer().has(ledgerKey, PersistentDataType.BYTE);
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent event) {
        if (!gameRunning) return;
        Player p = event.getPlayer();
        event.joinMessage(null);
        aliases.putIfAbsent(p.getUniqueId(), createAlias(aliases.size() + 1));
        applyMysteryIdentity(p);
        showAliasAboveHead(p);
        giveDeathNote(p);
        p.sendMessage(Component.text("You entered an active Black Ledger game.", NamedTextColor.DARK_PURPLE));
        p.sendMessage(Component.text("Your alias is " + aliases.get(p.getUniqueId()) + ".", NamedTextColor.LIGHT_PURPLE));
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent event) {
        if (gameRunning) event.quitMessage(null);
    }

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onChat(AsyncChatEvent event) {
        if (!gameRunning) return;
        Player p = event.getPlayer();
        String alias = aliases.getOrDefault(p.getUniqueId(), "Unknown");
        event.renderer((source, sourceDisplayName, message, viewer) ->
                Component.text("<" + alias + "> ", NamedTextColor.LIGHT_PURPLE).append(message));
    }

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onDeath(PlayerDeathEvent event) {
        if (!gameRunning) return;
        event.deathMessage(null);
        deadPlayers.add(event.getPlayer().getUniqueId());
        Bukkit.getScheduler().runTask(this, () -> {
            Player p = event.getPlayer();
            String alias = aliases.getOrDefault(p.getUniqueId(), "Unknown");
            Bukkit.broadcast(Component.text(alias + " has fallen.", NamedTextColor.DARK_GRAY));
        });
    }

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onEditBook(PlayerEditBookEvent event) {
        if (!gameRunning || !isDeathNote(event.getPlayer().getInventory().getItem(event.getSlot()))) return;
        if (!event.isSigning()) return;

        String targetName = extractTargetName(event.getNewBookMeta());
        if (targetName == null) {
            event.setCancelled(true);
            event.getPlayer().sendMessage(Component.text("The Ledger rejects the entry. Write exactly one real Minecraft username on the first non-empty line.", NamedTextColor.RED));
            return;
        }

        Player target = Bukkit.getPlayerExact(targetName);
        if (target == null || !target.isOnline() || deadPlayers.contains(target.getUniqueId())) {
            event.setCancelled(true);
            event.getPlayer().sendMessage(Component.text("The Ledger cannot find that living player.", NamedTextColor.RED));
            return;
        }

        if (target.getUniqueId().equals(event.getPlayer().getUniqueId())) {
            event.setCancelled(true);
            event.getPlayer().sendMessage(Component.text("The Ledger refuses its owner's name.", NamedTextColor.RED));
            return;
        }

        event.setCancelled(true);
        Player writer = event.getPlayer();
        String writerAlias = aliases.getOrDefault(writer.getUniqueId(), "Unknown");
        String targetAlias = aliases.getOrDefault(target.getUniqueId(), target.getName());

        if (getConfig().getBoolean("consume-note-on-kill", true)) {
            writer.getInventory().setItem(event.getSlot(), null);
        }

        Bukkit.broadcast(Component.text(targetAlias + " has been claimed by the Black Ledger.", NamedTextColor.DARK_PURPLE));
        Bukkit.getScheduler().runTask(this, () -> target.setHealth(0.0));
        writer.sendMessage(Component.text("The Ledger accepted the identity. Your action remains secret.", NamedTextColor.DARK_GRAY));
    }

    private String extractTargetName(BookMeta meta) {
        List<String> lines = new ArrayList<>();
        for (String page : meta.getPages()) {
            for (String line : page.split("\\R")) {
                String clean = ChatColor.stripColor(line).trim();
                if (!clean.isEmpty()) lines.add(clean);
            }
        }
        if (lines.size() != 1) return null;
        String candidate = lines.get(0);
        if (!candidate.matches("[A-Za-z0-9_]{3,16}")) return null;
        return candidate;
    }

    public boolean isRunning() { return gameRunning; }
    public Map<UUID, String> getAliases() { return Collections.unmodifiableMap(aliases); }

    public void giveNoteTo(Player p) { giveDeathNote(p); }

    public void showAlias(Player requester, Player target) {
        String alias = aliases.get(target.getUniqueId());
        if (alias == null) requester.sendMessage(Component.text("That player has no Black Ledger identity.", NamedTextColor.RED));
        else requester.sendMessage(Component.text(target.getName() + " is " + alias + ".", NamedTextColor.LIGHT_PURPLE));
    }
}
