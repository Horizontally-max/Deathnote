package com.jada.blackledger;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public final class LedgerCommand implements CommandExecutor {
    private final BlackLedger plugin;

    public LedgerCommand(BlackLedger plugin) { this.plugin = plugin; }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!sender.hasPermission("blackledger.admin")) {
            sender.sendMessage(Component.text("You do not have permission.", NamedTextColor.RED));
            return true;
        }
        if (args.length == 0) {
            sender.sendMessage(Component.text("/deathnote start | stop | give <player|all> | alias <player> | status", NamedTextColor.GRAY));
            return true;
        }
        switch (args[0].toLowerCase()) {
            case "start" -> plugin.startGame();
            case "stop" -> plugin.stopGame();
            case "status" -> sender.sendMessage(Component.text("Black Ledger is " + (plugin.isRunning() ? "RUNNING" : "STOPPED") + ". Players: " + plugin.getAliases().size(), NamedTextColor.LIGHT_PURPLE));
            case "give" -> {
                if (args.length < 2) { sender.sendMessage(Component.text("Usage: /deathnote give <player|all>", NamedTextColor.RED)); return true; }
                if (args[1].equalsIgnoreCase("all")) {
                    int count = 0;
                    for (Player p : Bukkit.getOnlinePlayers()) {
                        plugin.giveNoteTo(p);
                        count++;
                    }
                    sender.sendMessage(Component.text("Death Notes given to " + count + " online player(s).", NamedTextColor.GRAY));
                    return true;
                }
                Player p = Bukkit.getPlayerExact(args[1]);
                if (p == null) { sender.sendMessage(Component.text("Player not found.", NamedTextColor.RED)); return true; }
                plugin.giveNoteTo(p);
                sender.sendMessage(Component.text("Death Note given to " + p.getName() + ".", NamedTextColor.GRAY));
            }
            case "alias" -> {
                if (args.length < 2) { sender.sendMessage(Component.text("Usage: /deathnote alias <player>", NamedTextColor.RED)); return true; }
                Player target = Bukkit.getPlayerExact(args[1]);
                if (target == null) { sender.sendMessage(Component.text("Player not found.", NamedTextColor.RED)); return true; }
                plugin.showAlias(sender instanceof Player p ? p : Bukkit.getPlayerExact(args[1]), target);
            }
            default -> sender.sendMessage(Component.text("Unknown subcommand.", NamedTextColor.RED));
        }
        return true;
    }
}
