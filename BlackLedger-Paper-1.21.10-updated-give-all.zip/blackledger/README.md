# Black Ledger — Paper 1.21.10

A hidden-identity social-deduction Paper plugin inspired by the idea of a mysterious Death Note.

## What it does

- `/deathnote start` starts a game for everyone currently online.
- Every player receives a mysterious alias such as `Raven-01` and a special writable Death Note.
- While the game is active, tab names, chat names, and nameplates are replaced/hidden so real usernames are harder to identify.
- A player must discover another player's **real Minecraft username** through gameplay.
- They write exactly that username as the only non-empty line in their Death Note and sign it.
- If the name belongs to a living player, the target dies in-game.
- The writer is never announced.
- Death messages are hidden; only the target's mysterious alias is announced.
- Wrong/nonexistent names do nothing and the note remains usable.
- A player cannot target themselves.

## Admin commands

- `/deathnote start`
- `/deathnote stop`
- `/deathnote give <player>`
- `/deathnote alias <player>`
- `/deathnote status`

`/deathnote alias` is intended for admins/testing and should not be used during a serious mystery round.

## Build

Requires Java 21 and Maven.

```bash
mvn package
```

Put `target/BlackLedger-1.0.0.jar` in your Paper server's `plugins` folder.

## Important gameplay note

The plugin deliberately does not automatically reveal another player's real username. The social-deduction part is for the players to create: clues, conversations, disguises, screenshots, mistakes, and investigation can all be used to discover identities.

### Give Notes to Everyone

Use:

`/deathnote give all`

This gives a Death Note to every player currently online. The command requires the `blackledger.admin` permission (operators have it by default).
